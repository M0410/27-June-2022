function img2(){
    document.getElementById('id1').src=("../Day-9/animal\ image.jpg");
}
function img3(){
    document.getElementById('id1').src=("../Day-9/Bird1.webp");
}
function img4(){
    document.getElementById('id1').src=("../Day-9/Bird3.webp");
}
