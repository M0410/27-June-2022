function b1(){
    document.getelementById("id1").style.fontSize="100px";
}
function b2(){
    document.getelementById("id2").style.fontSize="100px";
}
function b3(){
    document.getelementById("id3").style.fontSize="100px";
}