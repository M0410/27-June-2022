$(document).ready(function(){
     $("#SOU").accordion();
        });