$(document).ready(function() {
    $( "#id1" ).datepicker({
        dateFormat: 'dd-mm-yy',
        shoewweek: true,
        yearSuffix:"-CE",
        showAnim:"slide"
    });

    $(function(){
        $("#id2").datepicker();
    });
});
